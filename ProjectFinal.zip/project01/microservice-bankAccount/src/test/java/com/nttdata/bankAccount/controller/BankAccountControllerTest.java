package com.nttdata.bankAccount.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nttdata.bankAccount.entity.BankAccount;
import com.nttdata.bankAccount.service.BankAccountServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.List;

import static org.hamcrest.Matchers.hasSize;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(controllers = BankAccountController.class)
@AutoConfigureMockMvc(addFilters = false)
@ExtendWith(MockitoExtension.class)
class BankAccountControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private BankAccountServiceImpl bankAccountService;

    @Autowired
    private ObjectMapper objectMapper;

    BankAccount bankAccount1 = new BankAccount(1L, "123456789", 10.0, "AHORROS", 1L);
    BankAccount bankAccount2 = new BankAccount(2L, "987654321", 20.0, "CORRIENTE", 1L);

    List<BankAccount> accounts = Arrays.asList(bankAccount1, bankAccount2);

    @Test
    void createBankAccount() throws Exception{

        mockMvc.perform(post("/api/bankAccount/cuentas")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(bankAccount1)))
                .andExpect(status().isCreated());

        verify(bankAccountService, times(1)).createBankAccount(any(BankAccount.class));

    }

    @Test
    void getBankAccounts() throws Exception{

        when(bankAccountService.getBankAccounts()).thenReturn(accounts);

        mockMvc.perform(get("/api/bankAccount/cuentas")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].balance").value(10.0))
                .andExpect(jsonPath("$[1].balance").value(20.0));

    }

    @Test
    void getBankAccountById() throws Exception{

        when(bankAccountService.getBankAccountById(1L)).thenReturn(bankAccount1);

        mockMvc.perform(get("/api/bankAccount/cuentas/1")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.balance").value(10.0));

    }

    @Test
    void deposit() throws Exception{

        BankAccount request = new BankAccount(1L, "123456789", 100.0, "AHORROS", 1L);

        String accountNumber = "123456789";

        mockMvc.perform(put("/api/bankAccount/cuentas/{accountNumber}/depositar", accountNumber)
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(request)))
                .andExpect(status().isOk());

        verify(bankAccountService, times(1)).deposit(request.getBalance(), accountNumber);

    }

    @Test
    void withdraw() throws Exception{

        BankAccount request = new BankAccount(1L, "123456789", 5.0, "AHORROS", 1L);
        String accountNumber = "123456789";

        mockMvc.perform(put("/api/bankAccount/cuentas/{accountNumber}/retirar", accountNumber)
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(request)))
                .andExpect(status().isOk());

        verify(bankAccountService, times(1)).withdraw(request.getBalance(), accountNumber);

    }

    @Test
    void deleteBankAccountById() throws Exception{

        mockMvc.perform(delete("/api/bankAccount/cuentas/1")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());

        verify(bankAccountService, times(1)).deleteBankAccountById(1L);

    }
}