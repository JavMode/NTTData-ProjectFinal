package com.nttdata.bankAccount.service;

import com.nttdata.bankAccount.entity.BankAccount;
import com.nttdata.bankAccount.repository.BankAccountRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BankAccountServiceImplTest {

    @Mock
    private BankAccountRepository bankAccountRepository;

    @InjectMocks
    private BankAccountServiceImpl bankAccountService;

    BankAccount bankAccount1 = new BankAccount(1L, "123456789", 10.0, "AHORROS", 1L);
    BankAccount bankAccount2 = new BankAccount(2L, "987654321", 20.0, "CORRIENTE", 2L);

    @Test
    void createBankAccount() {

        when(bankAccountRepository.save(Mockito.any(BankAccount.class))).thenReturn(bankAccount1);

        bankAccountService.createBankAccount(bankAccount1);

        verify(bankAccountRepository).save(bankAccount1);

    }

    @Test
    void getBankAccounts() {

        when(bankAccountRepository.findAll()).thenReturn(Arrays.asList(bankAccount1, bankAccount2));

        List<BankAccount> accounts = bankAccountService.getBankAccounts();

        assertNotNull(accounts);
        assertEquals(2, accounts.size());
        assertEquals("123456789", accounts.get(0).getAccountNumber());
        assertEquals("987654321", accounts.get(1).getAccountNumber());
        verify(bankAccountRepository).findAll();

    }

    @Test
    void getBankAccountById() {

        when(bankAccountRepository.findById(1L)).thenReturn(Optional.of(bankAccount1));

        BankAccount bankAccount = bankAccountService.getBankAccountById(1L);

        assertNotNull(bankAccount);
        assertEquals("123456789", bankAccount.getAccountNumber());
        verify(bankAccountRepository).findById(1L);

    }

    @Test
    void deposit() {

        when(bankAccountRepository.findByAccountNumber("123456789")).thenReturn(bankAccount1);

        bankAccountService.deposit(50.0, "123456789");

        assertEquals(60.0, bankAccount1.getBalance());

        verify(bankAccountRepository, times(1)).save(bankAccount1);

    }

    @Test
    void withdraw() {

        when(bankAccountRepository.findByAccountNumber("123456789")).thenReturn(bankAccount1);

        bankAccountService.withdraw(5.0, "123456789");

        assertEquals(5.0, bankAccount1.getBalance());

        verify(bankAccountRepository, times(1)).save(bankAccount1);

    }

    @Test
    void withdrawAhorros() {

        when(bankAccountRepository.findByAccountNumber("123456789")).thenReturn(bankAccount1);

        bankAccountService.withdraw(50.0, "123456789");

        assertEquals(10.0, bankAccount1.getBalance());

        verify(bankAccountRepository, times(0)).save(bankAccount1);

    }

    @Test
    void withdrawCorriente() {

        when(bankAccountRepository.findByAccountNumber("987654321")).thenReturn(bankAccount2);

        bankAccountService.withdraw(800.0, "987654321");

        assertEquals(20.0, bankAccount2.getBalance());
        assertEquals("CORRIENTE", bankAccount2.getAccountType());

        verify(bankAccountRepository, times(0)).save(bankAccount2);

    }

    @Test
    void deleteBankAccountById() {

        bankAccountService.deleteBankAccountById(1L);

        verify(bankAccountRepository).deleteById(1L);

    }
}