package com.nttdata.client.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nttdata.client.entity.Client;
import com.nttdata.client.service.ClientServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.List;

import static org.hamcrest.Matchers.hasSize;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

import static org.mockito.ArgumentMatchers.any;


@WebMvcTest(controllers = ClientController.class)
@AutoConfigureMockMvc(addFilters = false)
@ExtendWith(MockitoExtension.class)
class ClientControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ClientServiceImpl clientService;

    @Autowired
    private ObjectMapper objectMapper;

    Client client1 = new Client(1L, "Javier", "Wan", "70916266", "javierwan.14@gmail.com");
    Client client2 = new Client(2L, "Jose", "Vargas", "12345678", "jose.vargas@hotmail.com");

    List<Client> clients = Arrays.asList(client1, client2);

    @Test
    void getClients() throws Exception{

        when(clientService.getClients()).thenReturn(clients);

        mockMvc.perform(get("/api/clients/clientes")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].name").value("Javier"))
                .andExpect(jsonPath("$[1].name").value("Jose"));

    }

    @Test
    void saveClient() throws Exception{

        mockMvc.perform(post("/api/clients/clientes")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(client1)))
                .andExpect(status().isCreated());

        verify(clientService, times(1)).saveClient(any(Client.class));

    }

    @Test
    void getClientById() throws Exception{

        when(clientService.getClientById(1L)).thenReturn(client1);

        mockMvc.perform(get("/api/clients/clientes/1")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.name").value("Javier"));

    }

    @Test
    void updateClientById() throws Exception {

        Client client3 = new Client(1L, "Manuel", "Wan", "70916266", "javierwan.14@gmail.com");

        mockMvc.perform(put("/api/clients/clientes/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(client3)))
                .andExpect(status().isOk());

        verify(clientService, times(1)).updateClientById(any(Client.class),eq(1L));

    }

    @Test
    void deleteClientById() throws Exception{

        mockMvc.perform(delete("/api/clients/clientes/1")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());

        verify(clientService, times(1)).deleteClientById(1L);
    }
}