package com.nttdata.client.service;

import com.nttdata.client.entity.Client;
import com.nttdata.client.repository.ClientRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ClientServiceImplTest {

    @Mock
    private ClientRepository clientRepository;

    @InjectMocks
    private ClientServiceImpl clientService;

    Client client1 = new Client(1L, "Javier", "Wan", "70916266", "javierwan.14@gmail.com");
    Client client2 = new Client(2L, "Jose", "Vargas", "12345678", "jose.vargas@hotmail.com");

    @Test
    void getClients() {

        when(clientRepository.findAll()).thenReturn(Arrays.asList(client1, client2));

        List<Client> clients = clientService.getClients();

        assertNotNull(clients);
        assertEquals(2, clients.size());
        assertEquals("Javier", clients.get(0).getName());
        assertEquals("Jose", clients.get(1).getName());
        verify(clientRepository).findAll();

    }

    @Test
    void saveClient() {

        when(clientRepository.save(Mockito.any(Client.class))).thenReturn(client1);

        clientService.saveClient(client1);

        verify(clientRepository).save(client1);

    }

    @Test
    void getClientById() {

        when(clientRepository.findById(1L)).thenReturn(Optional.of(client1));

        Client client = clientService.getClientById(1L);

        assertNotNull(client);
        assertEquals("Javier", client.getName());
        verify(clientRepository).findById(1L);

    }

    @Test
    void updateClientById() {

        Client client3 = new Client(1L, "Manuel", "Wan", "70916266", "javierwan.14@gmail.com");

        when(clientRepository.findById(1L)).thenReturn(Optional.of(client1));

        clientService.updateClientById(client3, 1L);

        assertEquals("Manuel", client1.getName());
        verify(clientRepository).findById(1L);
        verify(clientRepository).save(client1);

    }

    @Test
    void deleteClientById() {

        clientService.deleteClientById(1L);

        verify(clientRepository).deleteById(1L);

    }
}