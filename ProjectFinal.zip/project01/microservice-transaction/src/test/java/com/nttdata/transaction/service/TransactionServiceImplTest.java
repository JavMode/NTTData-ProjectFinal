package com.nttdata.transaction.service;

import com.nttdata.transaction.entity.Transaction;
import com.nttdata.transaction.repository.TransactionRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class TransactionServiceImplTest {

    @Mock
    private TransactionRepository transactionRepository;

    @InjectMocks
    private TransactionServiceImpl transactionService;

    Transaction transaction1 = new Transaction("1", "DEPOSITO", 10.0, LocalDateTime.now(), "123456789");
    Transaction transaction2 = new Transaction("2", "RETIRO", 20.0, LocalDateTime.now(), "123456789");

    @Test
    void deposit() {

        when(transactionRepository.save(Mockito.any(Transaction.class))).thenReturn(transaction1);

        transactionService.deposit(transaction1);

        verify(transactionRepository).save(transaction1);

    }

    @Test
    void withdraw() {

        when(transactionRepository.save(Mockito.any(Transaction.class))).thenReturn(transaction1);

        transactionService.withdraw(transaction1);

        verify(transactionRepository).save(transaction1);

    }

    @Test
    void transfer() {

        when(transactionRepository.save(Mockito.any(Transaction.class))).thenReturn(transaction1);

        transactionService.transfer(transaction1);

        verify(transactionRepository).save(transaction1);

    }

    @Test
    void getHistory() {

        when(transactionRepository.findAll()).thenReturn(Arrays.asList(transaction1, transaction2));

        List<Transaction> transactions = transactionService.getHistory();

        assertNotNull(transactions);
        assertEquals(2, transactions.size());
        assertEquals(10.0, transactions.get(0).getAmount());
        assertEquals(20.0, transactions.get(1).getAmount());
        verify(transactionRepository).findAll();

    }
}