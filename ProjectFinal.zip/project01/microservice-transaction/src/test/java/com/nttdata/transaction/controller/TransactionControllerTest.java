package com.nttdata.transaction.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nttdata.transaction.bankaccount.BankAccountTransaction;
import com.nttdata.transaction.entity.Transaction;
import com.nttdata.transaction.service.TransactionService;
import com.nttdata.transaction.service.TransactionServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.Matchers.hasSize;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

@WebMvcTest(controllers = TransactionController.class)
@AutoConfigureMockMvc(addFilters = false)
@ExtendWith(MockitoExtension.class)
class TransactionControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private TransactionServiceImpl transactionService;

    @MockBean
    private BankAccountTransaction bankAccountTransaction;

    @Autowired
    private ObjectMapper objectMapper;

    Transaction transaction1 = new Transaction("1", "DEPOSITO", 10.0, LocalDateTime.now(), "123456789");
    Transaction transaction2 = new Transaction("2", "RETIRO", 20.0, LocalDateTime.now(), "123456789");

    List<Transaction> transactions = Arrays.asList(transaction1, transaction2);

    @Test
    void deposit() throws Exception{

        mockMvc.perform(post("/api/transactions/transacciones/deposito")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(transaction1)))
                .andExpect(status().isCreated());

        verify(bankAccountTransaction, times(1)).deposit(transaction1.getAmount(), transaction1.getAccount());
        verify(transactionService, times(1)).deposit(transaction1);

    }

    @Test
    void withdraw() throws Exception{

        mockMvc.perform(post("/api/transactions/transacciones/retiro")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(transaction1)))
                .andExpect(status().isCreated());

        verify(bankAccountTransaction, times(1)).withdraw(transaction1.getAmount(), transaction1.getAccount());
        verify(transactionService, times(1)).withdraw(transaction1);

    }

    @Test
    void transfer() throws Exception{

        mockMvc.perform(post("/api/transactions/transacciones/transferencia")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(transaction1)))
                .andExpect(status().isCreated());

        verify(bankAccountTransaction, times(1)).deposit(transaction1.getAmount(), transaction1.getAccount());
        verify(transactionService, times(1)).transfer(transaction1);

    }

    @Test
    void getHistory() throws Exception{

        when(transactionService.getHistory()).thenReturn(transactions);

        mockMvc.perform(get("/api/transactions/transacciones/historial")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].amount").value(10.0))
                .andExpect(jsonPath("$[1].amount").value(20.0));

    }
}