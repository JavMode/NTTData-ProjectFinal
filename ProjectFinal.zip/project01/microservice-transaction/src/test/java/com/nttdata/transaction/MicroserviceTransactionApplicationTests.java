package com.nttdata.transaction;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceTransactionApplicationTests {

	@Test
	void contextLoads() {
	}

}
