package com.nttdata.transaction.dto;

public class BankAccountDTO {
    private Double balance;

    public BankAccountDTO(){
    }

    public BankAccountDTO(Double balance){
        this.balance = balance;
    }

    public Double getBalance(){
        return this.balance;
    }

    public void setBalance(Double balance){
        this.balance = balance;
    }
}
